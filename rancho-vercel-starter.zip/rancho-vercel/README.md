# Rancho no Vercel — Sistema Agropecuário + Supabase + WhatsApp

Este pacote é um **starter técnico** para colocar o sistema no Vercel usando:

- **Next.js + React + TypeScript** para frontend e rotas serverless.
- **Tailwind CSS** para interface.
- **Supabase** como banco, Auth, Realtime e API principal.
- **WhatsApp Cloud API da Meta** como caminho recomendado para começar sem manter servidor próprio.
- Arquitetura com **adapter de WhatsApp desacoplado**, permitindo trocar Meta Cloud API por Evolution API, Z-API ou outro provedor no futuro.

> Importante: como as tabelas já existem no seu Supabase, o ponto principal é ajustar os nomes das tabelas e colunas em `src/lib/tables.ts` e nos serviços em `src/services`.

---

## Por que Vercel faz sentido aqui

O Vercel hospeda o painel web e também as rotas `/api` que servem como backend leve/webhook do WhatsApp. Assim você evita manter VPS, Docker ou Evolution API rodando 24h.

Arquitetura:

```txt
Usuário no WhatsApp
        ↓
Meta Cloud API
        ↓ webhook HTTPS
Vercel /api/whatsapp/webhook
        ↓
Motor de conversas + serviços
        ↓
Supabase
        ↓ realtime
Painel web atualiza dashboards
```

---

## Estrutura do projeto

```txt
rancho-vercel/
├─ README.md
├─ PROMPT_LOVABLE_VERCEL.md
├─ .env.example
├─ package.json
├─ vercel.json
├─ next.config.mjs
├─ tailwind.config.ts
├─ tsconfig.json
├─ postcss.config.mjs
├─ docs/
│  ├─ CONFIGURAR_META_CLOUD_API.md
│  ├─ CONFIGURAR_VERCEL.md
│  └─ MAPA_TABELAS_SUPABASE.md
└─ src/
   ├─ app/
   │  ├─ api/
   │  │  ├─ health/route.ts
   │  │  └─ whatsapp/webhook/route.ts
   │  ├─ estoque/page.tsx
   │  ├─ financeiro/page.tsx
   │  ├─ folha/page.tsx
   │  ├─ funcionarios/page.tsx
   │  ├─ globals.css
   │  ├─ layout.tsx
   │  ├─ page.tsx
   │  ├─ producao/page.tsx
   │  └─ rebanho/page.tsx
   ├─ components/
   ├─ hooks/
   ├─ lib/
   └─ services/
```

---

## Como rodar localmente

```bash
npm install
cp .env.example .env.local
npm run dev
```

Abra:

```txt
http://localhost:3000
```

---

## Variáveis de ambiente

Copie `.env.example` para `.env.local` e preencha:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

WHATSAPP_VERIFY_TOKEN=crie_um_token_forte
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_GRAPH_VERSION=v23.0
META_APP_SECRET=
```

### Regra de segurança

- `NEXT_PUBLIC_SUPABASE_ANON_KEY` pode ir para o frontend.
- `SUPABASE_SERVICE_ROLE_KEY`, `WHATSAPP_ACCESS_TOKEN` e `META_APP_SECRET` **nunca** podem ir para o frontend.
- As chaves secretas só devem ser usadas dentro de rotas server-side, como `/api/whatsapp/webhook`.

---

## Ajuste obrigatório: nomes das tabelas

Edite:

```txt
src/lib/tables.ts
```

Troque os nomes padrão pelos nomes reais do seu Supabase.

Exemplo:

```ts
export const TABLES = {
  animals: 'animais',
  milkProductions: 'producao_leite',
  financeEntries: 'financeiro',
  stockItems: 'estoque',
  employees: 'funcionarios',
  payrolls: 'folha_pagamento',
  whatsappSessions: 'whatsapp_sessions',
  activityLogs: 'logs_atividade',
} as const;
```

Também confira os nomes das colunas usadas nos inserts:

- produção leiteira: `animal_id`, `liters`, `production_date`, `source`
- animal: `name`, `tag_number`, `breed`, `birth_date`, `status`
- financeiro: `type`, `amount`, `category`, `description`, `date`, `source`
- sessões WhatsApp: `phone`, `state`, `payload`, `updated_at`

Se suas colunas tiverem nomes diferentes, ajuste em `src/services/whatsapp/engine.ts` e `src/services/dashboard.ts`.

---

## Deploy no Vercel

1. Suba este projeto para um repositório no GitHub.
2. Importe o repositório no Vercel.
3. Configure todas as variáveis de ambiente no Vercel.
4. Faça o deploy.
5. No painel da Meta, configure o webhook:

```txt
https://SEU-DOMINIO.vercel.app/api/whatsapp/webhook
```

Use o mesmo valor de `WHATSAPP_VERIFY_TOKEN` no campo de verificação da Meta.

---

## Fluxos de WhatsApp incluídos

### Menu inicial

Botões:

- Cadastrar Produção
- Cadastrar Animal
- Financeiro

### Produção

1. Usuário escolhe cadastrar produção.
2. Bot lista vacas cadastradas.
3. Usuário responde o número da vaca.
4. Bot pergunta quantos litros.
5. Sistema salva no Supabase.
6. Dashboard atualiza via Realtime.

### Animal

1. Bot pergunta nome.
2. Bot pergunta número do brinco.
3. Bot pergunta raça.
4. Bot pergunta data de nascimento.
5. Sistema salva no Supabase.

### Financeiro

1. Usuário escolhe receita ou despesa.
2. Bot pergunta valor.
3. Bot pergunta categoria.
4. Bot pergunta descrição.
5. Bot pergunta data.
6. Sistema salva no Supabase.

---

## Observação sobre custo zero

Este starter evita Evolution API porque ela normalmente exige servidor/instância rodando. Para começar com o menor custo operacional, a arquitetura usa o webhook do WhatsApp Cloud API direto no Vercel. Ainda assim, a cobrança oficial do WhatsApp Business Platform pode variar por categoria, país e regra vigente; valide sempre no painel da Meta antes de produção.

---

## Fontes oficiais úteis

- Vercel Functions: https://vercel.com/docs/functions
- Vercel Environment Variables: https://vercel.com/docs/environment-variables
- Supabase JS: https://supabase.com/docs/reference/javascript/introduction
- Supabase Realtime: https://supabase.com/docs/guides/realtime
- WhatsApp Webhooks: https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview/
- WhatsApp Interactive Reply Buttons: https://developers.facebook.com/documentation/business-messaging/whatsapp/messages/interactive-reply-buttons-messages/
- WhatsApp Pricing: https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing
