# Prompt completo para Lovable — Sistema Agropecuário no Vercel com Supabase e WhatsApp

Desenvolva uma aplicação web profissional para gestão agropecuária, focada em fazendas leiteiras, usando **Next.js, React, TypeScript, Tailwind CSS, Supabase e deploy no Vercel**.

Todas as tabelas já existem no Supabase. Portanto, o sistema deve consumir diretamente o Supabase usando o SDK oficial `@supabase/supabase-js`, sem recriar banco do zero. Centralize o mapeamento de nomes das tabelas em um arquivo como `src/lib/tables.ts`, para que eu consiga trocar os nomes facilmente caso minhas tabelas tenham nomes diferentes.

## Objetivo

Criar uma plataforma onde o produtor rural consiga gerenciar a operação da fazenda pelo painel administrativo web e também pelo WhatsApp. Toda informação cadastrada no painel ou pelo WhatsApp deve ser salva no Supabase e refletida em dashboards, relatórios e indicadores em tempo real.

## Stack obrigatória

- Next.js com App Router
- React
- TypeScript
- Tailwind CSS
- Supabase
- Supabase Realtime
- Vercel Functions para endpoints `/api`
- Arquitetura modular, escalável e fácil de manter

## Hospedagem

Preparar o projeto para deploy no Vercel.

Usar rotas serverless do Next.js para:

- Health check: `/api/health`
- Webhook WhatsApp: `/api/whatsapp/webhook`
- Futuras integrações

Não expor chaves secretas no frontend.

## Variáveis de ambiente

Criar `.env.example` com:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

WHATSAPP_VERIFY_TOKEN=
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_GRAPH_VERSION=v23.0
META_APP_SECRET=
```

## Segurança

- Usar `NEXT_PUBLIC_SUPABASE_ANON_KEY` apenas no frontend.
- Usar `SUPABASE_SERVICE_ROLE_KEY` apenas no servidor.
- Usar `WHATSAPP_ACCESS_TOKEN` apenas no servidor.
- Nunca colocar chaves secretas em componentes React client-side.
- Preparar o projeto para Row Level Security no Supabase.
- Validar webhook da Meta com `hub.verify_token` e `hub.challenge`.
- Implementar verificação opcional de assinatura `x-hub-signature-256` usando `META_APP_SECRET`.

## Módulos do sistema

### 1. Gestão de Rebanho

Criar telas e CRUD para:

- vacas
- bezerros
- touros
- número do brinco
- nome
- data de nascimento
- raça
- peso
- status: ativo, vendido, falecido
- histórico do animal
- controle de reprodução
- prenhez
- partos
- vacinação
- controle sanitário

### 2. Gestão de Produção Leiteira

Criar telas e CRUD para:

- registro diário de produção
- produção por vaca
- produção total da fazenda
- histórico por período
- média por animal
- ranking de produtividade
- gráficos e indicadores

### 3. Gestão de Estoque

Criar telas e CRUD para:

- produtos
- insumos
- ração
- medicamentos
- vacinas
- materiais diversos
- entradas
- saídas
- estoque mínimo
- alertas de reposição
- histórico de movimentações

### 4. Financeiro

Criar telas e CRUD para:

- contas a pagar
- contas a receber
- fluxo de caixa
- receitas
- despesas
- categorias financeiras
- relatórios financeiros
- indicadores de lucro e prejuízo

### 5. Gestão de Funcionários

Criar telas e CRUD para:

- cadastro de funcionários
- cargos
- salários
- benefícios
- férias
- presença
- histórico de pagamentos

### 6. Folha de Pagamento

Criar telas e CRUD para:

- geração de folha mensal
- salários
- adicionais
- descontos
- benefícios
- relatórios mensais
- histórico de pagamentos

## Dashboard principal

Criar dashboard inicial com cards, gráficos e indicadores para:

- total de animais
- produção diária
- produção mensal
- receita do mês
- despesas do mês
- lucro do mês
- estoque crítico
- funcionários ativos

O dashboard deve atualizar em tempo real usando Supabase Realtime.

## WhatsApp — módulo principal

Implementar um motor de chatbot para WhatsApp usando arquitetura desacoplada.

Criar:

```txt
src/services/whatsapp/types.ts
src/services/whatsapp/cloud-api.ts
src/services/whatsapp/engine.ts
src/app/api/whatsapp/webhook/route.ts
```

A integração deve ser feita inicialmente com **Meta Cloud API**, pois não exige manter servidor próprio como Evolution API. Porém a arquitetura deve permitir troca futura por Evolution API, Z-API ou outro provedor.

### Menu inicial

Mensagem:

```txt
Bem-vindo ao sistema da fazenda. Escolha uma opção:
```

Botões:

- Cadastrar Produção
- Cadastrar Animal
- Financeiro

### Fluxo: Cadastrar Produção

1. Usuário clica em Cadastrar Produção.
2. Bot pergunta: `Qual vaca produziu leite?`
3. Apresentar lista de vacas cadastradas no Supabase.
4. Usuário escolhe a vaca.
5. Bot pergunta: `Quantos litros foram produzidos?`
6. Usuário informa a quantidade.
7. Sistema salva automaticamente no Supabase.
8. Dashboard, relatórios e indicadores devem atualizar em tempo real.

### Fluxo: Cadastrar Animal

Perguntar em sequência:

- Nome
- Número do brinco
- Raça
- Data de nascimento

Ao finalizar:

- inserir no Supabase
- atualizar lista de rebanho
- atualizar dashboard

### Fluxo: Financeiro

Botões:

- Registrar Receita
- Registrar Despesa

Perguntar em sequência:

- Valor
- Categoria
- Descrição
- Data

Ao finalizar:

- salvar no Supabase
- atualizar fluxo de caixa
- atualizar dashboard financeiro

## Sessões do WhatsApp

Criar ou mapear uma tabela para controlar estado da conversa:

```txt
whatsapp_sessions
```

Colunas esperadas:

- phone
- state
- payload
- updated_at

A conversa deve ser stateful para saber em qual etapa o usuário está.

## Logs e auditoria

Criar sistema para registrar:

- criação de animal
- lançamento de produção
- lançamento financeiro
- movimentação de estoque
- alteração de funcionário
- origem do lançamento: painel ou WhatsApp
- usuário/telefone responsável
- data/hora

## Interface

Criar layout moderno com:

- sidebar de navegação
- header
- modo claro e escuro
- cards de resumo
- tabelas responsivas
- filtros avançados
- busca global
- gráficos
- formulários organizados
- feedback de sucesso/erro
- design limpo para uso no campo

## Relatórios e exportação

Preparar estrutura para:

- exportar PDF
- exportar Excel
- relatórios gerenciais por período
- relatórios por animal
- relatórios financeiros mensais
- relatório de estoque crítico

## Estrutura recomendada

```txt
src/
  app/
    api/
      whatsapp/webhook/route.ts
      health/route.ts
    page.tsx
    rebanho/page.tsx
    producao/page.tsx
    estoque/page.tsx
    financeiro/page.tsx
    funcionarios/page.tsx
    folha/page.tsx
  components/
    layout/
    dashboard/
    ui/
  hooks/
    use-table.ts
    use-realtime-table.ts
  lib/
    supabase/
      browser.ts
      server.ts
    tables.ts
    env.ts
  services/
    crud.ts
    dashboard.ts
    whatsapp/
      cloud-api.ts
      engine.ts
      types.ts
```

## Critérios de aceite

O projeto estará correto quando:

- Rodar localmente com `npm run dev`.
- Fazer deploy no Vercel.
- Ler e gravar no Supabase.
- Ter dashboard inicial funcional.
- Ter rotas por módulo.
- Ter webhook WhatsApp verificável pela Meta.
- Receber mensagem do WhatsApp e responder com botões.
- Cadastrar produção pelo WhatsApp no Supabase.
- Cadastrar animal pelo WhatsApp no Supabase.
- Cadastrar receita/despesa pelo WhatsApp no Supabase.
- Atualizar os dados do painel em tempo real.
- Nenhuma chave secreta aparecer no frontend.
