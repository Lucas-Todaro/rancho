# Mapa de tabelas Supabase

Edite `src/lib/tables.ts` para bater com os nomes reais das suas tabelas.

## Tabelas esperadas pelo starter

| Chave no código | Nome padrão | O que representa |
|---|---|---|
| animals | animals | Rebanho |
| milkProductions | milk_productions | Produção leiteira |
| stockItems | stock_items | Itens de estoque |
| stockMovements | stock_movements | Movimentações de estoque |
| financeEntries | financial_entries | Receitas e despesas |
| employees | employees | Funcionários |
| payrolls | payrolls | Folha de pagamento |
| whatsappSessions | whatsapp_sessions | Estado das conversas do chatbot |
| activityLogs | activity_logs | Logs e auditoria |

## Colunas usadas no chatbot

### animals

- `id`
- `name`
- `tag_number`
- `breed`
- `birth_date`
- `status`
- `source`
- `created_at`

### milk_productions

- `animal_id`
- `liters`
- `production_date`
- `source`
- `created_at`

### financial_entries

- `type`: receita ou despesa
- `amount`
- `category`
- `description`
- `date`
- `source`
- `created_at`

### whatsapp_sessions

- `phone`
- `state`
- `payload`
- `updated_at`

### activity_logs

- `action`
- `source`
- `metadata`
- `created_at`

Se seus nomes forem diferentes, ajuste o código nos arquivos:

- `src/services/whatsapp/engine.ts`
- `src/services/dashboard.ts`
