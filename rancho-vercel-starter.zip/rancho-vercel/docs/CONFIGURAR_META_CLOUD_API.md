# Configurar Meta Cloud API para WhatsApp

## 1. Criar app na Meta

1. Acesse Meta for Developers.
2. Crie um app do tipo negócios.
3. Adicione o produto WhatsApp.
4. Configure ou conecte um WhatsApp Business Account.

## 2. Pegar credenciais

Você precisará de:

- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `META_APP_SECRET`

Coloque esses valores nas variáveis de ambiente do Vercel.

## 3. Configurar webhook

Callback URL:

```txt
https://SEU-PROJETO.vercel.app/api/whatsapp/webhook
```

Verify token:

```txt
O mesmo valor de WHATSAPP_VERIFY_TOKEN
```

A rota GET já devolve o `hub.challenge` quando o token bate.

## 4. Assinar eventos

Assine pelo menos o evento de mensagens para receber mensagens dos usuários.

## 5. Testar

Envie `oi` para o número de teste/produção e o sistema deve responder com o menu inicial.
