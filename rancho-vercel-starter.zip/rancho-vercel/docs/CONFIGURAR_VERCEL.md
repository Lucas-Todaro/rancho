# Configurar Vercel

## 1. Criar projeto

1. Suba o código para GitHub.
2. Entre no Vercel.
3. Clique em `Add New Project`.
4. Selecione o repositório.
5. Framework: Next.js.
6. Build command: `npm run build`.
7. Output: padrão do Next.js.

## 2. Variáveis de ambiente

Em `Project Settings > Environment Variables`, adicione:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
WHATSAPP_VERIFY_TOKEN=
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_GRAPH_VERSION=v23.0
META_APP_SECRET=
```

Depois de alterar variáveis, faça redeploy.

## 3. URL do webhook

Depois do deploy, a URL será:

```txt
https://SEU-PROJETO.vercel.app/api/whatsapp/webhook
```

Use essa URL na configuração de Webhook do WhatsApp/Meta.
