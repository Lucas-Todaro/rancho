import Link from 'next/link';
import { BarChart3, Boxes, Calculator, ClipboardList, Cow, Home, Users, WalletCards } from 'lucide-react';

const items = [
  { href: '/', label: 'Dashboard', icon: Home },
  { href: '/rebanho', label: 'Rebanho', icon: Cow },
  { href: '/producao', label: 'Produção', icon: BarChart3 },
  { href: '/estoque', label: 'Estoque', icon: Boxes },
  { href: '/financeiro', label: 'Financeiro', icon: WalletCards },
  { href: '/funcionarios', label: 'Funcionários', icon: Users },
  { href: '/folha', label: 'Folha', icon: Calculator },
  { href: '/relatorios', label: 'Relatórios', icon: ClipboardList },
];

export function Sidebar() {
  return (
    <aside className="border-b bg-white md:min-h-screen md:w-72 md:border-b-0 md:border-r">
      <div className="p-5">
        <div className="rounded-2xl bg-rancho-600 p-4 text-white shadow-sm">
          <p className="text-sm opacity-80">Sistema</p>
          <h1 className="text-2xl font-bold">Rancho</h1>
        </div>
      </div>
      <nav className="flex gap-2 overflow-x-auto px-4 pb-4 md:block md:space-y-1 md:overflow-visible">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex min-w-fit items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-slate-700 hover:bg-rancho-50 hover:text-rancho-700"
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
