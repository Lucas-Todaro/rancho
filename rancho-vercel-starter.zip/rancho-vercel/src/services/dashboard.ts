import { createServerSupabase } from '@/lib/supabase/server';
import { TABLES } from '@/lib/tables';
import type { DashboardStats } from '@/lib/types';

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function firstDayOfMonthISO() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
}

function sumColumn(rows: any[] | null, column: string) {
  return (rows || []).reduce((total, row) => total + Number(row?.[column] || 0), 0);
}

async function safeCount(table: string, filter?: (query: any) => any) {
  try {
    const supabase = createServerSupabase();
    let query = supabase.from(table).select('*', { count: 'exact', head: true });
    if (filter) query = filter(query);
    const { count, error } = await query;
    if (error) return 0;
    return count || 0;
  } catch {
    return 0;
  }
}

async function safeRows(table: string, columns: string, filter?: (query: any) => any) {
  try {
    const supabase = createServerSupabase();
    let query = supabase.from(table).select(columns);
    if (filter) query = filter(query);
    const { data, error } = await query;
    if (error) return [];
    return data || [];
  } catch {
    return [];
  }
}

export async function getDashboardStats(): Promise<DashboardStats> {
  const today = todayISO();
  const firstDay = firstDayOfMonthISO();

  const [
    totalAnimals,
    dailyMilkRows,
    monthlyMilkRows,
    monthlyRevenueRows,
    monthlyExpenseRows,
    criticalStock,
    activeEmployees,
  ] = await Promise.all([
    safeCount(TABLES.animals),
    safeRows(TABLES.milkProductions, 'liters,production_date', (q) => q.eq('production_date', today)),
    safeRows(TABLES.milkProductions, 'liters,production_date', (q) => q.gte('production_date', firstDay)),
    safeRows(TABLES.financeEntries, 'amount,type,date', (q) => q.eq('type', 'receita').gte('date', firstDay)),
    safeRows(TABLES.financeEntries, 'amount,type,date', (q) => q.eq('type', 'despesa').gte('date', firstDay)),
    safeCount(TABLES.stockItems, (q) => q.lte('quantity', 'minimum_quantity')),
    safeCount(TABLES.employees, (q) => q.eq('status', 'ativo')),
  ]);

  const monthlyRevenue = sumColumn(monthlyRevenueRows, 'amount');
  const monthlyExpenses = sumColumn(monthlyExpenseRows, 'amount');

  return {
    totalAnimals,
    dailyMilk: sumColumn(dailyMilkRows, 'liters'),
    monthlyMilk: sumColumn(monthlyMilkRows, 'liters'),
    monthlyRevenue,
    monthlyExpenses,
    monthlyProfit: monthlyRevenue - monthlyExpenses,
    criticalStock,
    activeEmployees,
  };
}
