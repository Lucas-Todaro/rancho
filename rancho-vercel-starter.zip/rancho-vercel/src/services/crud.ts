import { createServerSupabase } from '@/lib/supabase/server';
import { TABLES, type TableKey } from '@/lib/tables';

export async function listRows<T = Record<string, unknown>>(tableKey: TableKey, limit = 100) {
  const supabase = createServerSupabase();
  const { data, error } = await supabase.from(TABLES[tableKey]).select('*').limit(limit);
  if (error) throw error;
  return (data || []) as T[];
}

export async function insertRow<T extends Record<string, unknown>>(tableKey: TableKey, payload: T) {
  const supabase = createServerSupabase();
  const { data, error } = await supabase.from(TABLES[tableKey]).insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateRow<T extends Record<string, unknown>>(tableKey: TableKey, id: string | number, payload: T) {
  const supabase = createServerSupabase();
  const { data, error } = await supabase.from(TABLES[tableKey]).update(payload).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteRow(tableKey: TableKey, id: string | number) {
  const supabase = createServerSupabase();
  const { error } = await supabase.from(TABLES[tableKey]).delete().eq('id', id);
  if (error) throw error;
  return true;
}
