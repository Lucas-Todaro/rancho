import { optionalEnv, requiredEnv } from '@/lib/env';
import type { IncomingWhatsAppMessage, WhatsAppButton, WhatsAppProvider } from './types';

function graphUrl(path: string) {
  const version = optionalEnv('WHATSAPP_GRAPH_VERSION', 'v23.0');
  return `https://graph.facebook.com/${version}/${path}`;
}

async function sendWhatsAppPayload(payload: Record<string, unknown>) {
  const phoneNumberId = requiredEnv('WHATSAPP_PHONE_NUMBER_ID');
  const accessToken = requiredEnv('WHATSAPP_ACCESS_TOKEN');

  const response = await fetch(graphUrl(`${phoneNumberId}/messages`), {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const details = await response.text();
    throw new Error(`Erro ao enviar WhatsApp: ${response.status} ${details}`);
  }
}

export const metaCloudApiProvider: WhatsAppProvider = {
  async sendText(to, text) {
    await sendWhatsAppPayload({
      messaging_product: 'whatsapp',
      to,
      type: 'text',
      text: { body: text },
    });
  },

  async sendButtons(to, body, buttons) {
    await sendWhatsAppPayload({
      messaging_product: 'whatsapp',
      to,
      type: 'interactive',
      interactive: {
        type: 'button',
        body: { text: body },
        action: {
          buttons: buttons.slice(0, 3).map((button: WhatsAppButton) => ({
            type: 'reply',
            reply: { id: button.id, title: button.title.slice(0, 20) },
          })),
        },
      },
    });
  },
};

export function parseIncomingWhatsAppMessages(payload: any): IncomingWhatsAppMessage[] {
  const messages: IncomingWhatsAppMessage[] = [];

  for (const entry of payload?.entry || []) {
    for (const change of entry?.changes || []) {
      for (const message of change?.value?.messages || []) {
        const interactive = message?.interactive;
        const buttonReply = interactive?.button_reply;
        const listReply = interactive?.list_reply;

        messages.push({
          from: message.from,
          text: message?.text?.body,
          buttonId: buttonReply?.id || listReply?.id,
          buttonTitle: buttonReply?.title || listReply?.title,
          raw: message,
        });
      }
    }
  }

  return messages;
}
