export type WhatsAppButton = {
  id: string;
  title: string;
};

export type IncomingWhatsAppMessage = {
  from: string;
  text?: string;
  buttonId?: string;
  buttonTitle?: string;
  raw: unknown;
};

export type WhatsAppProvider = {
  sendText(to: string, text: string): Promise<void>;
  sendButtons(to: string, body: string, buttons: WhatsAppButton[]): Promise<void>;
};

export type ConversationSession = {
  phone: string;
  state: string;
  payload: Record<string, unknown>;
};
