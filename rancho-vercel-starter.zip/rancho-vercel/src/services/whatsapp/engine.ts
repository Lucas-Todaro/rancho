import { createServerSupabase } from '@/lib/supabase/server';
import { TABLES } from '@/lib/tables';
import type { ConversationSession, IncomingWhatsAppMessage, WhatsAppProvider } from './types';

const STATES = {
  IDLE: 'IDLE',
  PRODUCTION_CHOOSE_COW: 'PRODUCTION_CHOOSE_COW',
  PRODUCTION_ENTER_LITERS: 'PRODUCTION_ENTER_LITERS',
  ANIMAL_NAME: 'ANIMAL_NAME',
  ANIMAL_TAG: 'ANIMAL_TAG',
  ANIMAL_BREED: 'ANIMAL_BREED',
  ANIMAL_BIRTH_DATE: 'ANIMAL_BIRTH_DATE',
  FINANCE_AMOUNT: 'FINANCE_AMOUNT',
  FINANCE_CATEGORY: 'FINANCE_CATEGORY',
  FINANCE_DESCRIPTION: 'FINANCE_DESCRIPTION',
  FINANCE_DATE: 'FINANCE_DATE',
} as const;

const BUTTONS = {
  MENU_PRODUCTION: 'MENU_PRODUCTION',
  MENU_ANIMAL: 'MENU_ANIMAL',
  MENU_FINANCE: 'MENU_FINANCE',
  FINANCE_REVENUE: 'FINANCE_REVENUE',
  FINANCE_EXPENSE: 'FINANCE_EXPENSE',
} as const;

function normalizeText(value?: string) {
  return (value || '').trim();
}

function parseBrazilianNumber(value: string) {
  const normalized = value.replace(/\./g, '').replace(',', '.').replace(/[^0-9.-]/g, '');
  const number = Number(normalized);
  return Number.isFinite(number) ? number : null;
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

async function getSession(phone: string): Promise<ConversationSession> {
  const supabase = createServerSupabase();
  const { data } = await supabase
    .from(TABLES.whatsappSessions)
    .select('phone,state,payload')
    .eq('phone', phone)
    .maybeSingle();

  return {
    phone,
    state: data?.state || STATES.IDLE,
    payload: data?.payload || {},
  };
}

async function saveSession(session: ConversationSession) {
  const supabase = createServerSupabase();
  await supabase.from(TABLES.whatsappSessions).upsert({
    phone: session.phone,
    state: session.state,
    payload: session.payload,
    updated_at: new Date().toISOString(),
  }, { onConflict: 'phone' });
}

async function clearSession(phone: string) {
  await saveSession({ phone, state: STATES.IDLE, payload: {} });
}

async function logActivity(action: string, source: string, metadata: Record<string, unknown>) {
  const supabase = createServerSupabase();
  await supabase.from(TABLES.activityLogs).insert({
    action,
    source,
    metadata,
    created_at: new Date().toISOString(),
  });
}

async function sendMainMenu(provider: WhatsAppProvider, to: string) {
  await provider.sendButtons(to, 'Bem-vindo ao sistema da fazenda. Escolha uma opção:', [
    { id: BUTTONS.MENU_PRODUCTION, title: 'Cadastrar Produção' },
    { id: BUTTONS.MENU_ANIMAL, title: 'Cadastrar Animal' },
    { id: BUTTONS.MENU_FINANCE, title: 'Financeiro' },
  ]);
}

async function startProductionFlow(provider: WhatsAppProvider, phone: string) {
  const supabase = createServerSupabase();
  const { data: animals, error } = await supabase
    .from(TABLES.animals)
    .select('id,name,tag_number,status')
    .eq('status', 'ativo')
    .limit(20);

  if (error || !animals?.length) {
    await provider.sendText(phone, 'Não encontrei vacas ativas cadastradas. Cadastre um animal primeiro.');
    await clearSession(phone);
    return;
  }

  const lines = animals.map((animal: any, index: number) => {
    const name = animal.name || 'Sem nome';
    const tag = animal.tag_number ? ` - brinco ${animal.tag_number}` : '';
    return `${index + 1}. ${name}${tag}`;
  });

  await saveSession({ phone, state: STATES.PRODUCTION_CHOOSE_COW, payload: { animals } });
  await provider.sendText(phone, `Qual vaca produziu leite?\n\n${lines.join('\n')}\n\nResponda com o número da vaca.`);
}

async function handleProductionChooseCow(provider: WhatsAppProvider, message: IncomingWhatsAppMessage, session: ConversationSession) {
  const choice = Number(normalizeText(message.text));
  const animals = (session.payload.animals || []) as any[];
  const animal = animals[choice - 1];

  if (!animal) {
    await provider.sendText(message.from, 'Não entendi a vaca escolhida. Responda com o número da lista.');
    return;
  }

  await saveSession({
    phone: message.from,
    state: STATES.PRODUCTION_ENTER_LITERS,
    payload: { animalId: animal.id, animalName: animal.name || animal.tag_number || animal.id },
  });
  await provider.sendText(message.from, `Quantos litros foram produzidos por ${animal.name || 'essa vaca'}?`);
}

async function handleProductionLiters(provider: WhatsAppProvider, message: IncomingWhatsAppMessage, session: ConversationSession) {
  const liters = parseBrazilianNumber(normalizeText(message.text));
  if (!liters || liters <= 0) {
    await provider.sendText(message.from, 'Informe uma quantidade válida de litros. Exemplo: 12,5');
    return;
  }

  const supabase = createServerSupabase();
  const payload = {
    animal_id: session.payload.animalId,
    liters,
    production_date: todayISO(),
    source: 'whatsapp',
    created_at: new Date().toISOString(),
  };

  const { error } = await supabase.from(TABLES.milkProductions).insert(payload);
  if (error) {
    await provider.sendText(message.from, `Erro ao salvar produção: ${error.message}`);
    return;
  }

  await logActivity('milk_production_created', 'whatsapp', { phone: message.from, ...payload });
  await clearSession(message.from);
  await provider.sendText(message.from, `Produção registrada com sucesso: ${liters} litros.`);
  await sendMainMenu(provider, message.from);
}

async function startAnimalFlow(provider: WhatsAppProvider, phone: string) {
  await saveSession({ phone, state: STATES.ANIMAL_NAME, payload: {} });
  await provider.sendText(phone, 'Qual é o nome do animal?');
}

async function handleAnimalFlow(provider: WhatsAppProvider, message: IncomingWhatsAppMessage, session: ConversationSession) {
  const text = normalizeText(message.text);
  if (!text) {
    await provider.sendText(message.from, 'Responda com uma informação válida.');
    return;
  }

  if (session.state === STATES.ANIMAL_NAME) {
    await saveSession({ phone: message.from, state: STATES.ANIMAL_TAG, payload: { name: text } });
    await provider.sendText(message.from, 'Qual é o número do brinco?');
    return;
  }

  if (session.state === STATES.ANIMAL_TAG) {
    await saveSession({ phone: message.from, state: STATES.ANIMAL_BREED, payload: { ...session.payload, tag_number: text } });
    await provider.sendText(message.from, 'Qual é a raça?');
    return;
  }

  if (session.state === STATES.ANIMAL_BREED) {
    await saveSession({ phone: message.from, state: STATES.ANIMAL_BIRTH_DATE, payload: { ...session.payload, breed: text } });
    await provider.sendText(message.from, 'Qual é a data de nascimento? Use o formato AAAA-MM-DD.');
    return;
  }

  const supabase = createServerSupabase();
  const animalPayload = {
    name: session.payload.name,
    tag_number: session.payload.tag_number,
    breed: session.payload.breed,
    birth_date: text,
    status: 'ativo',
    source: 'whatsapp',
    created_at: new Date().toISOString(),
  };

  const { error } = await supabase.from(TABLES.animals).insert(animalPayload);
  if (error) {
    await provider.sendText(message.from, `Erro ao cadastrar animal: ${error.message}`);
    return;
  }

  await logActivity('animal_created', 'whatsapp', { phone: message.from, ...animalPayload });
  await clearSession(message.from);
  await provider.sendText(message.from, 'Animal cadastrado com sucesso.');
  await sendMainMenu(provider, message.from);
}

async function startFinanceMenu(provider: WhatsAppProvider, phone: string) {
  await provider.sendButtons(phone, 'O que você deseja registrar?', [
    { id: BUTTONS.FINANCE_REVENUE, title: 'Receita' },
    { id: BUTTONS.FINANCE_EXPENSE, title: 'Despesa' },
  ]);
}

async function startFinanceFlow(provider: WhatsAppProvider, phone: string, type: 'receita' | 'despesa') {
  await saveSession({ phone, state: STATES.FINANCE_AMOUNT, payload: { type } });
  await provider.sendText(phone, `Qual é o valor da ${type}?`);
}

async function handleFinanceFlow(provider: WhatsAppProvider, message: IncomingWhatsAppMessage, session: ConversationSession) {
  const text = normalizeText(message.text);

  if (session.state === STATES.FINANCE_AMOUNT) {
    const amount = parseBrazilianNumber(text);
    if (!amount || amount <= 0) {
      await provider.sendText(message.from, 'Informe um valor válido. Exemplo: 1500,00');
      return;
    }
    await saveSession({ phone: message.from, state: STATES.FINANCE_CATEGORY, payload: { ...session.payload, amount } });
    await provider.sendText(message.from, 'Qual é a categoria?');
    return;
  }

  if (session.state === STATES.FINANCE_CATEGORY) {
    await saveSession({ phone: message.from, state: STATES.FINANCE_DESCRIPTION, payload: { ...session.payload, category: text } });
    await provider.sendText(message.from, 'Digite uma descrição curta.');
    return;
  }

  if (session.state === STATES.FINANCE_DESCRIPTION) {
    await saveSession({ phone: message.from, state: STATES.FINANCE_DATE, payload: { ...session.payload, description: text } });
    await provider.sendText(message.from, 'Qual é a data? Use AAAA-MM-DD ou envie "hoje".');
    return;
  }

  const date = text.toLowerCase() === 'hoje' ? todayISO() : text;
  const supabase = createServerSupabase();
  const financePayload = {
    type: session.payload.type,
    amount: session.payload.amount,
    category: session.payload.category,
    description: session.payload.description,
    date,
    source: 'whatsapp',
    created_at: new Date().toISOString(),
  };

  const { error } = await supabase.from(TABLES.financeEntries).insert(financePayload);
  if (error) {
    await provider.sendText(message.from, `Erro ao salvar financeiro: ${error.message}`);
    return;
  }

  await logActivity('finance_entry_created', 'whatsapp', { phone: message.from, ...financePayload });
  await clearSession(message.from);
  await provider.sendText(message.from, 'Lançamento financeiro registrado com sucesso.');
  await sendMainMenu(provider, message.from);
}

export async function handleWhatsAppMessage(provider: WhatsAppProvider, message: IncomingWhatsAppMessage) {
  const command = message.buttonId || normalizeText(message.text).toLowerCase();
  const session = await getSession(message.from);

  if (!message.from) return;

  if (!command || ['oi', 'olá', 'ola', 'menu', 'início', 'inicio'].includes(String(command).toLowerCase())) {
    await clearSession(message.from);
    await sendMainMenu(provider, message.from);
    return;
  }

  if (command === BUTTONS.MENU_PRODUCTION) {
    await startProductionFlow(provider, message.from);
    return;
  }

  if (command === BUTTONS.MENU_ANIMAL) {
    await startAnimalFlow(provider, message.from);
    return;
  }

  if (command === BUTTONS.MENU_FINANCE) {
    await startFinanceMenu(provider, message.from);
    return;
  }

  if (command === BUTTONS.FINANCE_REVENUE) {
    await startFinanceFlow(provider, message.from, 'receita');
    return;
  }

  if (command === BUTTONS.FINANCE_EXPENSE) {
    await startFinanceFlow(provider, message.from, 'despesa');
    return;
  }

  if (session.state === STATES.PRODUCTION_CHOOSE_COW) {
    await handleProductionChooseCow(provider, message, session);
    return;
  }

  if (session.state === STATES.PRODUCTION_ENTER_LITERS) {
    await handleProductionLiters(provider, message, session);
    return;
  }

  if ([STATES.ANIMAL_NAME, STATES.ANIMAL_TAG, STATES.ANIMAL_BREED, STATES.ANIMAL_BIRTH_DATE].includes(session.state as any)) {
    await handleAnimalFlow(provider, message, session);
    return;
  }

  if ([STATES.FINANCE_AMOUNT, STATES.FINANCE_CATEGORY, STATES.FINANCE_DESCRIPTION, STATES.FINANCE_DATE].includes(session.state as any)) {
    await handleFinanceFlow(provider, message, session);
    return;
  }

  await sendMainMenu(provider, message.from);
}
