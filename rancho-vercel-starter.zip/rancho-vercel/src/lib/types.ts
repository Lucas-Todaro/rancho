export type AnimalStatus = 'ativo' | 'vendido' | 'falecido';
export type FinanceType = 'receita' | 'despesa';
export type Source = 'painel' | 'whatsapp';

export type DashboardStats = {
  totalAnimals: number;
  dailyMilk: number;
  monthlyMilk: number;
  monthlyRevenue: number;
  monthlyExpenses: number;
  monthlyProfit: number;
  criticalStock: number;
  activeEmployees: number;
};
