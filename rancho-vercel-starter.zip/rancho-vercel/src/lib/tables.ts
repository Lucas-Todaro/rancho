/**
 * Troque estes nomes pelos nomes reais das tabelas que já existem no seu Supabase.
 * O objetivo é manter todo o projeto fácil de ajustar em um lugar só.
 */
export const TABLES = {
  animals: 'animals',
  milkProductions: 'milk_productions',
  stockItems: 'stock_items',
  stockMovements: 'stock_movements',
  financeEntries: 'financial_entries',
  employees: 'employees',
  payrolls: 'payrolls',
  whatsappSessions: 'whatsapp_sessions',
  activityLogs: 'activity_logs',
} as const;

export type TableKey = keyof typeof TABLES;
