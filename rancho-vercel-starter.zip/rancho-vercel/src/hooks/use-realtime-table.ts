'use client';

import { useEffect } from 'react';
import { supabaseBrowser } from '@/lib/supabase/browser';

export function useRealtimeTable(table: string, onChange: () => void) {
  useEffect(() => {
    const channel = supabaseBrowser
      .channel(`realtime:${table}`)
      .on('postgres_changes', { event: '*', schema: 'public', table }, onChange)
      .subscribe();

    return () => {
      supabaseBrowser.removeChannel(channel);
    };
  }, [table, onChange]);
}
