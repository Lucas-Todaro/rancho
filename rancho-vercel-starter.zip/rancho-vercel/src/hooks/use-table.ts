'use client';

import { useEffect, useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase/browser';

export function useTable<T = Record<string, unknown>>(table: string) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;

    async function load() {
      setLoading(true);
      const { data, error } = await supabaseBrowser.from(table).select('*').limit(100);
      if (!alive) return;
      if (error) setError(error.message);
      else setData((data || []) as T[]);
      setLoading(false);
    }

    load();

    return () => {
      alive = false;
    };
  }, [table]);

  return { data, loading, error };
}
