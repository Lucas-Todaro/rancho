import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { optionalEnv, requiredEnv } from '@/lib/env';
import { metaCloudApiProvider, parseIncomingWhatsAppMessages } from '@/services/whatsapp/cloud-api';
import { handleWhatsAppMessage } from '@/services/whatsapp/engine';

function verifySignature(rawBody: string, signatureHeader: string | null) {
  const appSecret = optionalEnv('META_APP_SECRET');

  // Em desenvolvimento você pode deixar META_APP_SECRET vazio.
  // Em produção, configure para validar que o webhook veio da Meta.
  if (!appSecret) return true;
  if (!signatureHeader?.startsWith('sha256=')) return false;

  const expected = 'sha256=' + crypto.createHmac('sha256', appSecret).update(rawBody).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(signatureHeader), Buffer.from(expected));
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const mode = searchParams.get('hub.mode');
  const token = searchParams.get('hub.verify_token');
  const challenge = searchParams.get('hub.challenge');

  if (mode === 'subscribe' && token === requiredEnv('WHATSAPP_VERIFY_TOKEN') && challenge) {
    return new NextResponse(challenge, { status: 200 });
  }

  return NextResponse.json({ error: 'Webhook não verificado' }, { status: 403 });
}

export async function POST(request: NextRequest) {
  const rawBody = await request.text();
  const signature = request.headers.get('x-hub-signature-256');

  if (!verifySignature(rawBody, signature)) {
    return NextResponse.json({ error: 'Assinatura inválida' }, { status: 401 });
  }

  let payload: unknown;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: 'JSON inválido' }, { status: 400 });
  }

  const messages = parseIncomingWhatsAppMessages(payload);

  await Promise.all(
    messages.map((message) => handleWhatsAppMessage(metaCloudApiProvider, message).catch((error) => {
      console.error('Erro no motor WhatsApp:', error);
    })),
  );

  return NextResponse.json({ received: true });
}
