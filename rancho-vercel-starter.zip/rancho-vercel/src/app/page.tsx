import { KpiCard } from '@/components/dashboard/kpi-card';
import { Card, CardDescription, CardTitle } from '@/components/ui/card';
import { getDashboardStats } from '@/services/dashboard';
import { formatCurrency, formatNumber } from '@/lib/utils';

export default async function DashboardPage() {
  const stats = await getDashboardStats();

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm font-medium text-rancho-700">Rancho</p>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard da fazenda</h1>
        <p className="mt-2 text-slate-500">Resumo operacional sincronizado com o Supabase.</p>
      </div>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard title="Total de animais" value={formatNumber(stats.totalAnimals)} />
        <KpiCard title="Produção diária" value={`${formatNumber(stats.dailyMilk)} L`} />
        <KpiCard title="Produção mensal" value={`${formatNumber(stats.monthlyMilk)} L`} />
        <KpiCard title="Lucro do mês" value={formatCurrency(stats.monthlyProfit)} />
        <KpiCard title="Receita do mês" value={formatCurrency(stats.monthlyRevenue)} />
        <KpiCard title="Despesas do mês" value={formatCurrency(stats.monthlyExpenses)} />
        <KpiCard title="Estoque crítico" value={formatNumber(stats.criticalStock)} />
        <KpiCard title="Funcionários ativos" value={formatNumber(stats.activeEmployees)} />
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardTitle>Próximo passo</CardTitle>
          <CardDescription>
            Ajuste os nomes de tabelas e colunas em <code>src/lib/tables.ts</code> e nos serviços para bater com seu Supabase.
          </CardDescription>
        </Card>
        <Card>
          <CardTitle>WhatsApp</CardTitle>
          <CardDescription>
            Configure o webhook da Meta apontando para <code>/api/whatsapp/webhook</code> depois do deploy no Vercel.
          </CardDescription>
        </Card>
      </section>
    </div>
  );
}
