import { Card, CardDescription, CardTitle } from '@/components/ui/card';

export default function Page() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Folha de Pagamento</h1>
        <p className="mt-2 text-slate-500">Gere folhas mensais com salários, adicionais, descontos, benefícios e histórico.</p>
      </div>
      <Card>
        <CardTitle>CRUD do módulo</CardTitle>
        <CardDescription>
          Esta tela está pronta para receber tabela, formulário, filtros, exportação e conexão com os serviços Supabase.
          Use <code className="mx-1">src/services/crud.ts</code> e o mapeamento de tabelas em <code className="mx-1">src/lib/tables.ts</code>.
        </CardDescription>
      </Card>
    </div>
  );
}
